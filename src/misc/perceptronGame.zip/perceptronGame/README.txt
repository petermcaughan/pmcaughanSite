The file 'v2.0' contains the source code for the perceptron guessing game.

Running the python file will kick off the game, and entering 1 or 2 iteratively will train the program.
The instructions are self-explanatory, so the program will lead you through how it works.

Looking at the source code is interesting though! Check out how it's constructed.