
The program works as follows after navigating to this folder:

	1. Open up a terminal and enter command " ./csrd "
	2. Open up another terminal and enter command " ./crc "
	3. Enter command as [command] [name] where command is CREATE, DESTROY, or JOIN and name is any integer.
	4. Open up multiple clients and perform different actions.
		For testing total JOIN functionality, have two or three clients enter the same chatroom instead of one.
	