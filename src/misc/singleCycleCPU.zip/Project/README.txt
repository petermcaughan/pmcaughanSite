Each file in this folder is a module used to complete the CPU.

SingleCycleCPU is the module that ties everything together and can execute 32-bit instructions.