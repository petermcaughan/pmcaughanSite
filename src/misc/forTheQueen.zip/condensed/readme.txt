This project is a little more difficult to run on a local machine.

Run the server.js program on the machine you'd like to host on, and then connect to the server through two 
different browsers to start the game! Or just view the video shown at https://www.youtube.com/watch?v=jVVChJlAjTA 
and browse the source code.
